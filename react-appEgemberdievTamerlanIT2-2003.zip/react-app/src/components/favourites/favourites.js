import React,{Component} from 'react';
import './favourites.css';

import PokemonCard from '../pokemon-card';
import PokemonDetails from '../pokemon-details';

export default class Favourites extends Component {
  state = {
    selectedPokemon: null,
  };

  handleCardClick = (pokemon) => {
    this.setState({ selectedPokemon: pokemon });
  };

  handleModalClose = () => {
    this.setState({ selectedPokemon: null });
  };

  render() {
    const { favorites, onAddToFavorites, onRemoveFromFavorites } = this.props;
    const { selectedPokemon } = this.state;

    return (
      <div className="favourites">
        <h2>Favourites</h2>
        <div className="pokemon-cards">
          {favorites.length > 0 ? (
            favorites.map((pokemon) => {
              const imageUrl = pokemon.sprites?.front_default || '';
              return (
                <PokemonCard
                  key={pokemon.name}
                  name={pokemon.name}
                  imageUrl={imageUrl}
                  onClick={() => this.handleCardClick(pokemon)}
                />
              );
            })
          ) : (
            <p>No favorite Pokemon yet</p>
          )}
        </div>

        {selectedPokemon && (
          <div className="modal-overlay">
            <PokemonDetails
              pokemon={selectedPokemon}
              onClose={this.handleModalClose}
              onAddToFavorites={onAddToFavorites}
              onRemoveFromFavorites={onRemoveFromFavorites}
              isFavorite={favorites.some((favorite) => favorite.name === selectedPokemon.name)}
            />
          </div>
        )}
      </div>
    );
  }
}


