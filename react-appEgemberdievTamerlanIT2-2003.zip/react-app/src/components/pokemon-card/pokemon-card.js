import React, { Component } from 'react';
import './pokemon-card.css'

export default class PokemonCard extends Component {

    state = {
        imageLoaded: false,
      };

    async componentDidMount() {
        const { imageUrl } = this.props;
        await this.loadImage(imageUrl);
      }

      loadImage = async (imageUrl) => {
        try {
          await new Promise((resolve, reject) => {
            const image = new Image();
            image.onload = resolve;
            image.onerror = reject;
            image.src = imageUrl;
          });
          this.setState({ imageLoaded: true });
        } catch (error) {
          console.log('Error loading image:', error);
        }
      };

  render() {
    const { name, imageUrl, onClick, type = '' } = this.props;
    const { imageLoaded } = this.state;

    const cardClassName = `pokemon-card ${type.toLowerCase()}`;
    
    return (
      <div className={cardClassName} onClick={onClick}>
        {imageLoaded ? (
          <img src={imageUrl} alt={name} className="pokemon-image" />
        ) : (
          <p>Loading image...</p>
        )}
        <p>{name}</p>
      </div>
    );
  }
}