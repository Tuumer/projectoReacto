import PokemonCard from "./pokemon-card";

export default PokemonCard;