import PokemonDetails from './pokemon-details';
export default PokemonDetails;