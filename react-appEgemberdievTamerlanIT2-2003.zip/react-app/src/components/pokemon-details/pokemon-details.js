import React, { Component } from 'react';

export default class PokemonDetails extends Component {
    handleFavoriteClick = () => {
      const { pokemon, onAddToFavorites, onRemoveFromFavorites, isFavorite } = this.props;
      if (isFavorite) {
        onRemoveFromFavorites(pokemon);
      } else {
        onAddToFavorites(pokemon);
      }
    };
  
    render() {
      const { pokemon, onClose, isFavorite } = this.props;
      const { name, sprites, types, stats, species, abilities, locations } = pokemon;
  
      return (
        <div className="pokemon-details">
          <div className="pokemon-details-content">
            <div className="pokemon-details-header">
              <h2>{name}</h2>
              <button className="close-button" onClick={onClose}>
                Close
              </button>
            </div>
            <div className="pokemon-details-body">
              <div className="pokemon-details-image">
                <img src={sprites.front_default} alt={name} />
              </div>
              <div className="pokemon-details-info">
              {types && (
  <div className="pokemon-details-type">
    <h3>Type:</h3>
    <ul>
      {types.map((type) => (
        <li
          key={type.type.name}
          className={`pokemon-type-${type.type.name}`}
        >
          {type.type.name}
        </li>
      ))}
    </ul>
  </div>
)}
                {abilities && (
                  <div className="pokemon-details-abilities">
                    <h3>Abilities:</h3>
                    <ul>
                      {abilities.map((ability) => (
                        <li key={ability.ability.name}>{ability.ability.name}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {stats && (
                  <div className="pokemon-details-stats">
                    <h3>Stats:</h3>
                    <ul>
                      {stats.map((stat) => (
                        <li key={stat.stat.name}>
                          {stat.stat.name}: {stat.base_stat}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {species && (
                  <div className="pokemon-details-evolution">
                    <h3>Evolution:</h3>
                    <ul>
                      <li>
                        <img
                          src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${species.url.split('/')[6]}.png`}
                          alt={name}
                        />
                        {name}
                      </li>
                    </ul>
                  </div>
                )}
                {locations && (
                  <div className="pokemon-details-locations">
                    <h3>Locations:</h3>
                    <ul>
                      {locations.map((location) => (
                        <li key={location.location.name}>{location.location.name}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              <div className="pokemon-details-favorite">
                <button
                  className={`heart-button ${isFavorite ? 'heart-button-active' : ''}`}
                  onClick={this.handleFavoriteClick}
                >
                  <i className="fa fa-heart" />
                </button>
                
              </div>
            </div>
          </div>
        </div>
      );
    }
  }
  

