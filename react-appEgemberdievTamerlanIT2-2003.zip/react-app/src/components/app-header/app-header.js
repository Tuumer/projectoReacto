import React from "react";
import './app-header.css';

import { Link, Routes,Route } from 'react-router-dom';
import App from "../app/app";
import Favourites from "../favourites";
import Locations from "../locations";

const AppHeader = () => {
  return (
    <div className="header d-flex">
      <h3>
        <Link to="/">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/International_Pok%C3%A9mon_logo.svg/1200px-International_Pok%C3%A9mon_logo.svg.png" alt="Pokemons" />
        </Link>
      </h3>
      <ul className="d-flex">
        <li>
          <Link to="/">Pokemons</Link>
        </li>
        <li>
          <Link to="/locations">Locations</Link>
        </li>
        <li>
          <Link to="/favourites">Favourites</Link>
        </li>
      </ul>
      <Routes>
        <Route path="/" element={App} />
        <Route path="/locations" element={Locations} />
        <Route path="/favourites" element={Favourites} />
      </Routes>
    </div>
  );
};


export default AppHeader;
