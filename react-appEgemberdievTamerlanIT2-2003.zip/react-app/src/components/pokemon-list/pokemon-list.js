// import React from 'react';
// import PokemonCard from '../pokemon-card';

// import './pokemon-list.css';

// const PokemonList = ({ pokemonList, onCardClick }) => {
//   return (
//     <div className="pokemon-list">
//       {pokemonList.map((pokemon) => (
//         <PokemonCard
//           key={pokemon.name}
//           name={pokemon.name}
//           imageUrl={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png`}
//           onClick={() => onCardClick(pokemon)}
//           type={pokemon.types[0]} 
//         />
//       ))}
//     </div>
//   );
// };

// export default PokemonList;