import React, {useEffect,useState} from 'react';
import axios from 'axios';

const Locations = () => {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch('https://pokeapi.co/api/v2/location');
      const data = await response.json();
      setLocations(data.results);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="locations-container">
      <h2 className="locations-heading">Locations</h2>
      {locations.length > 0 ? (
        <div className="locations-grid">
          {locations.map((location) => (
            <div key={location.name} className="location-item">
              <div className="location-image"></div>
              <span className="location-name">{location.name}</span>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-locations">No locations found.</p>
      )}
    </div>
  );
};

export default Locations;
