import Locations from './locations';
export default Locations;