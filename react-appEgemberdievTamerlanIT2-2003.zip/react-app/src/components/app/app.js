import React, {Component, useState,useEffect} from 'react';


import AppHeader from '../app-header';
import SearchPanel from '../search-panel';
import PokemonCard from '../pokemon-card';
// import PokemonList from '../pokemon-list/pokemon-list';
import axios from "axios";
import PokemonDetails from '../pokemon-details';
import Favourites from '../favourites';
import Locations from '../locations';
import { BrowserRouter as Router, Switch, Route, Link, Routes } from 'react-router-dom';

import './app.css';

const App = () => {
    const [pokemonList, setPokemonList] = useState([]);
    const [offset, setOffset] = useState(0);
    const [limit] = useState(20);
    const [selectedPokemon, setSelectedPokemon] = useState(null);
    const [favorites, setFavorites] = useState([]);
    const [searchFilter, setSearchFilter] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [allPokemonList, setAllPokemonList] = useState([]);
  
    useEffect(() => {
      fetchAllPokemonData();
    }, []);
  
    const fetchAllPokemonData = async () => {
      try {
        const response = await axios.get(`https://pokeapi.co/api/v2/pokemon?limit=2000`);
        const data = response.data.results;
  
        const pokemonListWithTypes = await Promise.all(
          data.map(async (pokemon) => {
            const response = await axios.get(pokemon.url);
            const pokemonData = response.data;
            const types = pokemonData.types.map((type) => type.type.name);
            return { ...pokemon, types };
          })
        );

        setAllPokemonList(pokemonListWithTypes);
        setPokemonList(pokemonListWithTypes.slice(offset, offset + limit));
      } catch (error) {
        console.log(error);
      }
    };
  
    const handleNext = () => {
      setOffset((prevOffset) => prevOffset + limit);
      updateDisplayedPokemonList(offset + limit);
    };
  
    const handleBack = () => {
      setOffset((prevOffset) => Math.max(prevOffset - limit, 0));
      updateDisplayedPokemonList(Math.max(offset - limit, 0));
    };
  
    const updateDisplayedPokemonList = (newOffset) => {
      setPokemonList(allPokemonList.slice(newOffset, newOffset + limit));
    };
  
    const handleCardClick = async (pokemon) => {
      try {
        const response = await axios.get(pokemon.url);
        const pokemonData = response.data;
        setSelectedPokemon(pokemonData);
        setShowModal(true);
      } catch (error) {
        console.log(error);
      }
    };
  
    const handleModalClose = () => {
      setShowModal(false);
    };
  
    const handleAddToFavorites = (pokemon) => {
      setFavorites((prevFavorites) => [...prevFavorites, pokemon]);
    };
  
    const handleRemoveFromFavorites = (pokemon) => {
      setFavorites((prevFavorites) =>
        prevFavorites.filter((favorite) => favorite.name !== pokemon.name)
      );
    };
  
    const handleSearchChange = (term) => {
      setSearchFilter(term);
      const filteredPokemonList = allPokemonList.filter((pokemon) =>
        pokemon.name.toLowerCase().includes(term.toLowerCase())
      );
      setPokemonList(filteredPokemonList.slice(offset, offset + limit));
    };
  
    return (
      <div className="todo-app">
        <div className="top-panel d-flex align-items-center">
          <AppHeader />
          <SearchPanel onSearchChange={handleSearchChange} />
        </div>
  
        <Routes>
          <Route
            exact
            path="/"
            element={<PokemonList pokemonList={pokemonList} onCardClick={handleCardClick} />}
          />
          <Route path="/pokemon/:id" element={<PokemonDetails />} />
          <Route path="/locations" element={<Locations />} />
          <Route path="/favourites" element={<Favourites favorites={favorites} onAddToFavorites={handleAddToFavorites} onRemoveFromFavorites={handleRemoveFromFavorites} />} />
        </Routes>
  
        <div className="pages-buttons">
          <button onClick={handleBack}>Back</button>
          <button onClick={handleNext}>Next</button>
        </div>
  
        {showModal && selectedPokemon && (
          <div className="modal-overlay">
            <PokemonDetails
              pokemon={selectedPokemon}
              onClose={handleModalClose}
              onAddToFavorites={handleAddToFavorites}
              onRemoveFromFavorites={handleRemoveFromFavorites}
              isFavorite={favorites.some((favorite) => favorite.name === selectedPokemon.name)}
            />
          </div>
        )}
      </div>
    );
  };
  
  export default App;

const PokemonList = ({ pokemonList, onCardClick }) => {
  return (
    <div className="pokemon-cards">
      {pokemonList.length > 0 ? (
        pokemonList.map((pokemon) => (
          <PokemonCard
            key={pokemon.name}
            name={pokemon.name}
            type={pokemon.type}
            imageUrl={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.url.split('/')[6]}.png`}
            onClick={() => onCardClick(pokemon)}
          />
        ))
      ) : (
        <p>No pokemons</p>
      )}
    </div>
  );
};
  
